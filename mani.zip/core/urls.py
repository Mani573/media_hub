from django.urls import path
from . import views
from .views import CustomLoginView
from django.conf.urls.static import static
from django.conf import settings

urlpatterns = [
    path('signup/', views.consumer_signup, name='consumer_signup'),
    path('login/signup/', views.consumer_signup, name='consumer_signup'),
    path('upload/', views.upload_video, name='upload_video'),
    path('videos/', views.video_list, name='video_list'),
    path('videos/<int:pk>/', views.video_detail, name='video_detail'),
    path('videos/<int:pk>/comment/', views.add_comment, name='add_comment'),
    path('videos/<int:pk>/rate/', views.add_rating, name='add_rating'),
    path('login/', CustomLoginView.as_view(), name='login'),
    path('',views.index,name='home'),
    path('creator_dashboard/', views.creator_dashboard,name='creator_dashboard' ),
    path('like-video/<int:video_id>/', views.like_video, name='like_video'),
    path('logout/', views.logout_view, name='logout'),
    path('my_videos/', views.creator_video_list, name='my_videos'),
    path('about',views.about,name='about'),
] + static(settings.STATIC_URL, document_root=settings.STATIC_ROOT)

urlpatterns += static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)

